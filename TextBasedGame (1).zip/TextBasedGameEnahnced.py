# Charity Deel
# Enhanced Text-Based Game
# Algorithms and Data Structures Artifact

# -----------------------------
# Room Data Structure
# -----------------------------

rooms = {
    "Maze Entrance": {
        "description": "You stand at the entrance of the maze.",
        "exits": {"East": "Demeter's Garden"},
        "item": None
    },

    "Demeter's Garden": {
        "description": "A peaceful garden filled with vines and ancient flowers.",
        "exits": {
            "North": "Athena's Library",
            "South": "Ares's Weaponry",
            "East": "Fate's Corridors",
            "West": "Maze Entrance"
        },
        "item": "Golden Apple"
    },

    "Athena's Library": {
        "description": "A quiet library filled with scrolls of ancient wisdom.",
        "exits": {
            "South": "Demeter's Garden",
            "East": "Zeus's Throne Room"
        },
        "item": "Scroll"
    },

    "Zeus's Throne Room": {
        "description": "A grand hall glowing with divine lightning.",
        "exits": {"West": "Athena's Library"},
        "item": "Lightning Bolt"
    },

    "Fate's Corridors": {
        "description": "A twisting hallway where every path feels uncertain.",
        "exits": {
            "West": "Demeter's Garden",
            "North": "Hecate's Corner"
        },
        "item": "Ball of Yarn"
    },

    "Hecate's Corner": {
        "description": "A shadowed corner filled with magical energy.",
        "exits": {"South": "Fate's Corridors"},
        "item": "Potion of Strength"
    },

    "Ares's Weaponry": {
        "description": "A room lined with weapons from ancient battles.",
        "exits": {
            "North": "Demeter's Garden",
            "East": "Daedalus's Lair"
        },
        "item": ["Sword", "Club"]
    },

    "Daedalus's Lair": {
        "description": "The lair of the Minotaur. The final battle awaits.",
        "exits": {"West": "Ares's Weaponry"},
        "item": "Minotaur"
    }
}


# -----------------------------
# Game Constants
# -----------------------------

REQUIRED_ITEMS = {
    "Golden Apple",
    "Scroll",
    "Lightning Bolt",
    "Ball of Yarn",
    "Potion of Strength",
    "Sword"
}

FINAL_ROOM = "Daedalus's Lair"

DIRECTIONS = {"North", "South", "East", "West"}

INSTRUCTIONS = """
Welcome to the Maze!

Goal:
Collect the required items and defeat the Minotaur.

Commands:
Move: North, South, East, or West
Collect item: get item
Check inventory: inventory
View score: score
View stats: stats
Exit game: exit
"""


# -----------------------------
# Utility Functions
# -----------------------------

def normalize_command(command):
    """
    Normalizes user input by removing extra spaces and converting
    the command into title case for direction matching.
    """
    return command.strip()


def has_item(inventory, item_name):
    """
    Searches the inventory list to determine whether a specific item exists.
    This demonstrates a basic linear search algorithm.
    """
    for item in inventory:
        if item.lower() == item_name.lower():
            return True
    return False


def has_required_items(inventory):
    """
    Compares the player's inventory against the required item set.
    This demonstrates set-based comparison for efficient requirement checking.
    """
    inventory_set = set(inventory)
    return REQUIRED_ITEMS.issubset(inventory_set)


def get_missing_items(inventory):
    """
    Determines which required items are still missing.
    This uses set difference to compare the required item set
    against the player's current inventory.
    """
    inventory_set = set(inventory)
    missing_items = REQUIRED_ITEMS - inventory_set
    return sorted(missing_items)


def display_status(current_room, inventory, score, moves):
    """
    Displays the player's current room, room description, inventory,
    score, move count, available exits, and visible item.
    """
    room = rooms[current_room]

    print("\n-----------------------------")
    print("Current Room:", current_room)
    print(room["description"])
    print("Inventory:", inventory)
    print("Score:", score)
    print("Moves:", moves)
    print("Available exits:", ", ".join(room["exits"].keys()))

    item = room.get("item")

    if item and item != "Minotaur":
        if isinstance(item, list):
            print("You see:", ", ".join(item))
        else:
            print("You see:", item)

    print("-----------------------------")


def display_inventory(inventory):
    """
    Displays all collected inventory items.
    """
    if inventory:
        print("\nInventory Items:")
        for item in inventory:
            print("-", item)
    else:
        print("\nYour inventory is empty.")


def display_stats(score, moves, visited_rooms, inventory):
    """
    Displays gameplay statistics.
    """
    print("\nGame Statistics")
    print("Score:", score)
    print("Moves Taken:", moves)
    print("Rooms Visited:", len(visited_rooms))
    print("Rooms Visited List:", ", ".join(sorted(visited_rooms)))
    print("Items Collected:", len(inventory))


# -----------------------------
# Game Logic Functions
# -----------------------------

def move_player(command, current_room, visited_rooms):
    """
    Moves the player between rooms using the exits dictionary.
    This demonstrates dictionary lookup for room traversal.
    """
    room_exits = rooms[current_room]["exits"]

    direction = command.title()

    if direction in room_exits:
        new_room = room_exits[direction]
        visited_rooms.add(new_room)
        print("You moved to:", new_room)
        return new_room, True

    print("You cannot go that way.")
    return current_room, False


def collect_item(current_room, inventory):
    """
    Collects the item from the current room and adds it to inventory.
    This function supports both single-item rooms and multi-item rooms.
    """
    item = rooms[current_room].get("item")

    if item is None:
        print("There is no item to pick up here.")
        return inventory, 0

    if item == "Minotaur":
        print("You cannot pick up the Minotaur.")
        return inventory, 0

    points_earned = 0

    if isinstance(item, list):
        for single_item in item:
            if not has_item(inventory, single_item):
                inventory.append(single_item)
                points_earned += 10
                print("You picked up:", single_item)

    else:
        if not has_item(inventory, item):
            inventory.append(item)
            points_earned += 10
            print("You picked up:", item)

    rooms[current_room]["item"] = None

    return inventory, points_earned


def check_final_battle(inventory, score):
    """
    Determines whether the player wins or loses when entering
    Daedalus's Lair.
    """
    if has_required_items(inventory):
        score += 50
        print("\nCongratulations!")
        print("You collected the required items and defeated the Minotaur.")
        print("Final Score:", score)
        return True, score

    missing_items = get_missing_items(inventory)

    print("\nOh no! You entered Daedalus's Lair unprepared.")
    print("You were slain by the Minotaur.")
    print("Missing Required Items:", ", ".join(missing_items))
    print("Final Score:", score)

    return True, score


# -----------------------------
# Main Game Loop
# -----------------------------

def main():
    current_room = "Maze Entrance"
    inventory = []
    score = 0
    moves = 0
    visited_rooms = {"Maze Entrance"}

    print(INSTRUCTIONS)

    while True:
        display_status(current_room, inventory, score, moves)

        if current_room == FINAL_ROOM:
            game_over, score = check_final_battle(inventory, score)
            if game_over:
                break

        command = normalize_command(input("What would you like to do? "))

        if command.lower() == "exit":
            print("Thanks for playing!")
            break

        elif command.lower() == "inventory":
            display_inventory(inventory)

        elif command.lower() == "score":
            print("Current Score:", score)

        elif command.lower() == "stats":
            display_stats(score, moves, visited_rooms, inventory)

        elif command.title() in DIRECTIONS:
            current_room, successful_move = move_player(
                command,
                current_room,
                visited_rooms
            )

            if successful_move:
                moves += 1
            else:
                score -= 5

        elif command.lower().startswith("get"):
            inventory, points = collect_item(current_room, inventory)
            score += points

        else:
            print("Invalid command. Try again.")
            score -= 5


if __name__ == "__main__":
    main()