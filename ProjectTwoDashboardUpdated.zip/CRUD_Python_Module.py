# Charity Deel
# Enhanced Animal Shelter CRUD Module
# Database Artifact Enhancement for CS 499

from pymongo import MongoClient, ASCENDING
from pymongo import errors


class AnimalShelter:
    """CRUD operations for the AAC animal collection in MongoDB."""

    def __init__(self, username='aacuser', password='Password123', host='localhost',
                 port=27017, database='aac', collection='animals', auth_source='admin'):

        self.client = MongoClient(
            f"mongodb://{username}:{password}@{host}:{port}/?authSource={auth_source}"
        )

        self.database = self.client[database]
        self.collection = self.database[collection]
        self.create_indexes()

    def create_indexes(self):
        """Create indexes for common dashboard queries."""
        try:
            self.collection.create_index([('animal_type', ASCENDING)])
            self.collection.create_index([('breed', ASCENDING)])
            self.collection.create_index([('sex_upon_outcome', ASCENDING)])
            self.collection.create_index([('age_upon_outcome_in_weeks', ASCENDING)])
            self.collection.create_index([('location_lat', ASCENDING), ('location_long', ASCENDING)])
        except errors.PyMongoError:
            pass

    def create(self, data):
        """Insert one document."""
        if not isinstance(data, dict) or not data:
            return False

        try:
            result = self.collection.insert_one(data)
            return result.acknowledged and result.inserted_id is not None
        except errors.PyMongoError:
            return False

    def read(self, query=None, projection=None, sort=None, limit=0):
        """Read documents from the collection."""
        if query is None:
            query = {}

        if projection is None:
            projection = {}

        if not isinstance(query, dict) or not isinstance(projection, dict):
            return []

        try:
            cursor = self.collection.find(query, projection)

            if sort:
                cursor = cursor.sort(sort)

            if isinstance(limit, int) and limit > 0:
                cursor = cursor.limit(limit)

            return list(cursor)

        except errors.PyMongoError:
            return []

    def update(self, query, new_values):
        """Update matching documents."""
        if not isinstance(query, dict) or not query:
            return 0

        if not isinstance(new_values, dict) or not new_values:
            return 0

        try:
            result = self.collection.update_many(query, {'$set': new_values})
            return result.modified_count
        except errors.PyMongoError:
            return 0

    def delete(self, query):
        """Delete matching documents."""
        if not isinstance(query, dict) or not query:
            return 0

        try:
            result = self.collection.delete_many(query)
            return result.deleted_count
        except errors.PyMongoError:
            return 0

    def build_rescue_filter(self, rescue_type):
        """Return MongoDB filters for Grazioso Salvare rescue categories."""

        if rescue_type == 'water':
            return {
                'animal_type': 'Dog',
                'breed': {
                    '$in': [
                        'Labrador Retriever Mix',
                        'Chesapeake Bay Retriever',
                        'Newfoundland'
                    ]
                },
                'sex_upon_outcome': 'Intact Female',
                'age_upon_outcome_in_weeks': {'$gte': 26, '$lte': 156}
            }

        if rescue_type == 'mountain':
            return {
                'animal_type': 'Dog',
                'breed': {
                    '$in': [
                        'German Shepherd',
                        'Alaskan Malamute',
                        'Old English Sheepdog',
                        'Siberian Husky',
                        'Rottweiler'
                    ]
                },
                'sex_upon_outcome': 'Intact Male',
                'age_upon_outcome_in_weeks': {'$gte': 26, '$lte': 156}
            }

        if rescue_type == 'disaster':
            return {
                'animal_type': 'Dog',
                'breed': {
                    '$in': [
                        'Doberman Pinscher',
                        'German Shepherd',
                        'Golden Retriever',
                        'Bloodhound',
                        'Rottweiler'
                    ]
                },
                'sex_upon_outcome': 'Intact Male',
                'age_upon_outcome_in_weeks': {'$gte': 20, '$lte': 300}
            }

        return {} 